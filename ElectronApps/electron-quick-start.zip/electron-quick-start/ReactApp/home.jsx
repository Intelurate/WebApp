import React, { Component } from 'react';

var fs = require('fs-extra');
//var request = require('request');

var http = require('http');

//import axios from 'axios';

class Home extends Component {

    constructor() {
        super();
    }

    async httpRequest(){
        // let response = await axios.get(`http://localhost:7272/test-api-get`);
        // alert(response.data.name);

        
        http.get({
            hostname: 'localhost',
            port: 7272,
            path: '/test-api-get',
            agent: false  // create a new agent just for this one request
          }, (res) => {

            res.setEncoding('utf8');
            let rawData = '';
            res.on('data', (chunk) => { rawData += chunk; });
            res.on('end', () => {
              try {
                const parsedData = JSON.parse(rawData);
                console.log(parsedData);
              } catch (e) {
                console.error(e.message);
              }
            });

          
            // Do stuff with response
          });


        // http.get('http://localhost:7272/test-api-get', function (err, res) {
        //     if (err) {
        //         console.error(err);
        //         return;
        //     }
            
        //     console.log(res.code, res.headers, res.buffer.toString());
        // });

    }

    createFile(){

        fs.writeFile("helloworld.txt", "Hey there!", function(err) {
                if(err) {
                        return console.log(err);
                }
                alert('done')
                console.log("The file was saved!");
        });

    }
    
    render(){
        return (
            <div>
               <p>Home Page Fool</p>
               <p onClick={e=>this.createFile()}>Create File</p>
               <p onClick={e=>this.httpRequest()}>Call Api</p>
            </div>
        )
    }
}



export { Home };