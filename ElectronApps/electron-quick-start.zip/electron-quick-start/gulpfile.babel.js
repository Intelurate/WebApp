import path from 'path'

import gulp from 'gulp';
import run from 'gulp-run';
import webpack from 'webpack';
import gutil from "gulp-util";
import gls from 'gulp-live-server';
import env from 'gulp-env';
import _ from 'underscore';
import mocha from 'gulp-mocha';
import through from "through2";
import yaml from 'gulp-yaml';
import log from 'fancy-log';
import babel from 'gulp-babel';

let buildPath = 'bin';

let srcPath = 'server';

gulp.task('webpack:build-jsx', (callback) => {
    
    var webpackTargetElectronRenderer = require('webpack-target-electron-renderer');


    let options = require('./webpack.config');
    options.target = webpackTargetElectronRenderer(options);

    //var webpackConfig = options;

    // add minification if using minified environment
    // if (minifiedEnvironments.indexOf(gutil.env.node_env) !== -1)

    //webpackConfig.plugins.push(new webpack.optimize.UglifyJsPlugin());

    return webpack(options, function (err, stats) {
        if (err) throw new gutil.PluginError("webpack", err);
        gutil.log("[webpack]", stats.toString({
            chunks: false,
            colors: true
        }));
        callback();
    });
});



gulp.task('default', ['webpack:build-jsx']);
