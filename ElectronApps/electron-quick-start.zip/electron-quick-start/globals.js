var fs = require('fs');

window.writeFile = function(){

    fs.writeFile("hello3.txt", "Hey there!", function(err) {
        if(err) {
            return console.log(err);
        }
        alert('done')
        console.log("The file was saved!");
    }); 

}